//Clase Hija
public class Control extends Post {
    public Control(String autor_post, String fecha, int likes, String tu_texto, String coments, String hastaghs, String emoticion){
        super(autor_post, fecha, likes, tu_texto, coments, hastaghs, emoticion);
    }

    public void mostrar(){
        // forma de red social uno
        System.out.println(" "+getAutor_Post()+ " "+getFecha()+" Likes:  "+getLikes()+"\n (Texto)"+getTu_texto()+"\n "+getHastaghs()+"\n---Comentario---\n"+getComents()+"\n");    

        
    }

    public void mostrar1(){
        
        //forma de red social dos(Emoticones)
        System.out.println(" "+getAutor_Post()+" "+getFecha()+" Likes:  "+getLikes()+"\n (Texto) "+getTu_texto()+" (emoticon) "+getEmoticon()+"\n");
    }

    public void mostrar2(){
        // forma de red social con Multimedia
        System.out.println(" "+getAutor_Post()+ " "+getFecha()+" Likes:  "+getLikes()+"\n "+getHastaghs()+"\n"+getTu_texto()+"\n---Comentario---\n"+getComents()+"\n");
    }
    
}
