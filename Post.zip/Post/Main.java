// 22808 Sergio Palacios
//Lab 3
public class Main {
    public static void main(String []args){
        Control control = new Control("Luis", "9/09/2022", 4, "Tengo Hambre", "1. Comeeee algoo \n2. me gustas ", "#UVG #HAMBRE", null);
        control.mostrar();

        Control control2 = new Control("Fernanda", "10/09/2022", 0, "Hola", null, null, ":)");
        control2.mostrar1();

        Control control3 = new Control("Isabella", "11/09/2022", 3, "(video) https://www.youtube.com/watch?v=QmGcBP-JkLs \n105 KB, JPEG, 7 Megapixeles", "1. Vamosssss", "#FIESTA #FELIZ #FERXXO", ":)");
        control3.mostrar2();

    }
    
}
