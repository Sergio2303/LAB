// Clase Hija
public class Multimedia extends Post {
    private String audio;
    private String video;
    private String imagen;

    public Multimedia(String autor_post, String fecha, int likes, String tu_texto, String coments, String hastaghs, String emoticion, String audio, String video, String imagen ){
        super(autor_post,fecha,likes,tu_texto,coments,hastaghs,emoticion);
        this.audio = audio;
        this.video = video;
        this.imagen = imagen;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }
    public String getVideo() {
        return video;
    }
    public void setVideo(String video) {
        this.video = video;
    }
    public String getImagen() {
        return imagen;
    }
    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
    
    
}
