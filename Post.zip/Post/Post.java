// Clase Madre
public class Post {
    private String autor_Post;
    private String fecha;
    private int likes;
    private String tu_texto;
    private String coments;
    private String hastaghs;
    private String emoticon;
    
    public Post(String autor_post, String fecha, int likes, String tu_texto, String coments, String hastaghs, String emoticion){
        
        this.autor_Post = autor_post;
        this.fecha = fecha;
        this.likes = likes;
        this.tu_texto = tu_texto;
        this.coments = coments;
        this.hastaghs = hastaghs;
        this.emoticon = emoticion;
    }
    public String getAutor_Post() {
        return autor_Post;
    }

    public void setAutor_Post(String autor_Post) {
        this.autor_Post = autor_Post;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public int getLikes() {
        return likes;
    }
    public void setLikes(int likes) {
        this.likes = likes;
    }
    public String getTu_texto() {
        return tu_texto;
    }
    public void setTu_texto(String tu_texto) {
        this.tu_texto = tu_texto;
    }
    public String getComents() {
        return coments;
    }
    public void setComents(String coments) {
        this.coments = coments;
    }
    public String getHastaghs() {
        return hastaghs;
    }
    public void setHastaghs(String hastaghs) {
        this.hastaghs = hastaghs;
    }
    public String getEmoticon() {
        return emoticon;
    }
    public void setEmoticon(String emoticon) {
        this.emoticon = emoticon;
    }

    

}
